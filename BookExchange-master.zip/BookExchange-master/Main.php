<html>
    <head>     
<link rel = "stylesheet" href = "MainMenu.css" type = "text/css"/>
</head>
        <body>
        <?php
include("MainMenu.php");
        ?>
        </body>
        </html>